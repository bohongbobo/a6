var searchData=
[
  ['restart',['restart',['../classmain__savitch__14_1_1Othello.html#abf872b8074bfa4c04119317dc3b39af2',1,'main_savitch_14::Othello']]]
];

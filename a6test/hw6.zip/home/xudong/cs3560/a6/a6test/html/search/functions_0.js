var searchData=
[
  ['compute_5fmoves',['compute_moves',['../classmain__savitch__14_1_1Othello.html#aae15562565348c574b8e4c0b7782d19f',1,'main_savitch_14::Othello']]],
  ['countingpieces',['countingPieces',['../classmain__savitch__14_1_1Othello.html#a19f49edfbe82b84922877e00bc854ed8',1,'main_savitch_14::Othello']]]
];

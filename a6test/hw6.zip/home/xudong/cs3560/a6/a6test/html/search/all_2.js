var searchData=
[
  ['display_5fstatus',['display_status',['../classmain__savitch__14_1_1Othello.html#a471f0e8f0e63ed32d764682f60110267',1,'main_savitch_14::Othello']]]
];

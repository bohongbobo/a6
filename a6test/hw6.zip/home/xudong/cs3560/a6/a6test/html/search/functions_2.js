var searchData=
[
  ['evaluate',['evaluate',['../classmain__savitch__14_1_1Othello.html#a1b3239a14882cbc7e7bd44c0b6828514',1,'main_savitch_14::Othello']]]
];
